package ro.pub.cs.systems.eim.exe_practicaltest02

import java.net.Socket
import java.net.URL
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.io.PrintWriter
import org.json.JSONObject
import javax.net.ssl.HttpsURLConnection

class CommunicationThread(private val serverThread: ServerThread, private val clientSocket: Socket) : Thread() {
    
    var prt_log: Boolean = true

    fun prt_debug(msg: String) {
        if (prt_log)
            Log.i(General.TAG, "[COMMUNICATION THREAD ${this.id}] $msg")
    }
    
    override fun run() {
        prt_debug("A început comunicarea cu un client.")

        try {
            val inputStream = BufferedReader(InputStreamReader(clientSocket.getInputStream()))
            val outputStream = PrintWriter(clientSocket.getOutputStream(), true)
            
            val str = inputStream.readLine()
            
            if (str.isNullOrEmpty()) {
                outputStream.println("Error: No string provided")
                return
            }
            
            prt_debug("Requested key -- s: $str")
            
            // Check cache first
            var information = serverThread.getData(str)
            
            if (information == null) {
                // Fetch from API
                prt_debug("Cache miss, fetching from API...")
                information = fetchData(str)
                
                if (information != null) {
                    serverThread.setData(str, information)
                }
            } else {
                prt_debug("Cache hit!")
            }
            
            // Send response to client
            if (information != null) {
                outputStream.println(information.toString())
            } else {
                outputStream.println("Error: Could not fetch weather data")
            }
            
        } catch (e: IOException) {
            prt_debug("Error: ${e.message}")
        } finally {
            try {
                clientSocket.close()
            } catch (e: IOException) {
                prt_debug("Error closing socket: ${e.message}")
            }
        }
    }
    
    private fun fetchData(s_key_for_info: String): Information? {
        return try {
            val url = URL("${General.WEB_SERVICE_ADRESS}?q=$s_key_for_info&appid=${General.WEB_SERVICE_API_KEY}&units=${General.UNITS}")
            val connection = url.openConnection() as HttpsURLConnection
            connection.requestMethod = "GET"
            
            val reader = BufferedReader(InputStreamReader(connection.inputStream))
            val response = StringBuilder()
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                response.append(line)
            }
            reader.close()
            
            val json = JSONObject(response.toString())
            val main = json.getJSONObject("main")
            val wind = json.getJSONObject("wind")
            val weather = json.getJSONArray("weather").getJSONObject(0)
            
            Information(
                temperature = main.getDouble("temp").toString() + "°C",
                windSpeed = wind.getDouble("speed").toString() + " m/s",
                condition = weather.getString("description"),
                pressure = main.getInt("pressure").toString() + " hPa",
                humidity = main.getInt("humidity").toString() + "%"
            )
        } catch (e: Exception) {
            prt_debug("API Error: ${e.message}")
            null
        }
    }
}
