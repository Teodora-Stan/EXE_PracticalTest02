package ro.pub.cs.systems.eim.exe_practicaltest02

object General {
    const val TAG = "[PracticalTest02]"
    const val WEB_SERVICE_API_KEY = "e03c3b32cfb5a6f7069f2ef29237d87e"
    const val WEB_SERVICE_ADRESS = "https://api.openweathermap.org/data/2.5/weather"
    const val UNITS = "metric"
}