Teodora Stan 341C2

